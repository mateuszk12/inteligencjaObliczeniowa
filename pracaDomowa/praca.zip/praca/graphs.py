import pygad
import networkx as nx
import matplotlib.pyplot as plt



def hamilton1(graph,results:bool):
    flatten = [item for sub_list in graph for item in sub_list]
    number_of_nodes = len(set(flatten))
    gene_space = [i for i in range(len(graph))]


    def fitness_function(solution, solution_idx):
        fitness = 0
        path = [graph[int(i)] for i in solution]
        visited = {}
        flatten = [item for sub_list in path for item in sub_list]
        incoming = {}
        outcoming = {}
        repeat_counter = 0
        repeat_incoming = 0
        repeat_outcoming = 0
        # ile i które wierzchołki zostały odwiedzone
        for i in path:
            if i[0] not in incoming:
                incoming[i[0]] = 1
            else:
                repeat_incoming += 1
                incoming[i[0]] += 1
            if i[1] not in outcoming:
                outcoming[i[1]] = 1
            else:
                repeat_outcoming += 1
                outcoming[i[1]] += 1
        nodes_incoming = len(incoming)
        nodes_outcoming = len(outcoming)
        fitness -= 2000 * (number_of_nodes - nodes_incoming) * number_of_nodes
        fitness -= 2000 * (number_of_nodes - nodes_outcoming) * number_of_nodes
        fitness -= 2000 * (repeat_outcoming) * number_of_nodes
        fitness -= 2000 * (repeat_incoming) * number_of_nodes
        for i in visited:
            if visited[i] != 2:
                fitness -= 1000 * number_of_nodes * visited[i]
        if repeat_counter > 0:
            fitness -= 3000 * number_of_nodes * repeat_counter - 1

        # sprawdzanie spójności grafu
        for i in range(len(path)):
            if i > 0:
                if path[i][0] == path[i - 1][1]:
                    fitness += 900 * number_of_nodes
                else:
                    fitness -= 1200 * number_of_nodes

        # sprawdza czy to cykl
        if path[0][0] == path[-1][1]:
            fitness += 1000 * number_of_nodes
        else:
            fitness -= 3000 * number_of_nodes

        return fitness


    sol_per_pop = 100 * number_of_nodes
    num_genes = number_of_nodes
    num_parents_mating = 5
    num_generations = 5 * number_of_nodes
    keep_parents = 2
    parent_selection_type = "sss"
    crossover_type = "single_point"
    mutation_type = "random"
    mutation_percent_genes = 18
    ga_instance = pygad.GA(gene_space=gene_space,
                        num_generations=num_generations,
                        num_parents_mating=num_parents_mating,
                        fitness_func=fitness_function,
                        sol_per_pop=sol_per_pop,
                        num_genes=num_genes,
                        parent_selection_type=parent_selection_type,
                        keep_parents=keep_parents,
                        crossover_type=crossover_type,
                        mutation_type=mutation_type,
                        mutation_percent_genes=mutation_percent_genes,
                        stop_criteria=[f"saturate_{60}"],
                        allow_duplicate_genes=False)

    ga_instance.run()
    if results:
        ga_instance.plot_fitness()
    solution = ga_instance.best_solution()
    optimal_nodes = [graph[int(i)] for i in solution[0]]

    flatten = [item for sub_list in optimal_nodes for item in sub_list]
    incoming = {}
    outcoming = {}
    repeat_counter = 0
    nodes_incoming = len(incoming)
    nodes_outcoming = len(outcoming)
    repeat_incoming = 0
    repeat_outcoming = 0
    for i in optimal_nodes:
        if i[0] not in incoming:
            incoming[i[0]] = 1
        else:
            repeat_incoming += 1
            incoming[i[0]] += 1
        if i[1] not in outcoming:
            outcoming[i[1]] = 1
        else:
            repeat_outcoming += 1
            outcoming[i[1]] += 1
    nodes_incoming = len(incoming)
    nodes_outcoming = len(outcoming)
    if results:
        print(solution[1],
            f"repeated[incoming,outcoming][{repeat_incoming},{repeat_outcoming}],nodes[incoming,outcoming][{nodes_incoming},{nodes_outcoming}],number of nodes: {number_of_nodes}")
        print(optimal_nodes)
    
        G = nx.DiGraph(directed=True)
        for i in flatten:
            G.add_node(i)
        for i in graph:
            G.add_edge(*i)
        options = {
            "font_size": 17,
            "node_size": 500,
            "node_color": "white",
            "edgecolors": "black",
            "linewidths": 3,
            "width": 1,
            'arrowstyle': '-|>',
            'arrowsize': 7,
        }
        for i in G.edges():
            if i in optimal_nodes[0:number_of_nodes]:
                G[i[0]][i[1]]['color'] = 'red'
            else:
                G[i[0]][i[1]]['color'] = 'black'
        edge_color_list = [G[e[0]][e[1]]['color'] for e in G.edges()]
        black = [edge for edge in G.edges() if edge not in optimal_nodes]
        pos = nx.circular_layout(G)
        nx.draw_networkx(G, pos, arrows=True, edge_color=edge_color_list, connectionstyle="arc3,rad=0.2", **options)
        ax = plt.gca()
        ax.margins(0.20)
        plt.axis("off")
        plt.show()
    connected = True
    for i in range(len(optimal_nodes)):
            if i > 0:
                if optimal_nodes[i][0] != optimal_nodes[i - 1][1]:
                    connected = False
    if repeat_incoming == 0 and repeat_outcoming == 0 and connected:
        return True
    else:
        return False
